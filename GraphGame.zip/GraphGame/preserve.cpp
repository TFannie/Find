#include "stdafx.h"

void preserve(play * head)  //��������
{
	cleardevice();
	loadimage(nullptr, L"IMAGE\\timg13.jpg", 640, 480); 
	std::fstream file;
	city *own=head->next;
	file.open("play.txt", std::ios::out);
	file.seekg(0, file.beg);
	file << head->cname << ' '
		<< head->ipeople << ' '
		<< head->iarmy << ' '
		<< head->grain << ' '
		<< head->icity << ' ';
	while (own != nullptr)
	{
		file << own->cname << ' ';
		own = own->next;
	}
	file.close();
	setbkmode(OPAQUE);
	setbkcolor(RGB(0,100,225));
	settextcolor(WHITE);
	rectangle(80,90,200,120);
	outtextxy(100, 100, L"����ɹ���");
	setbkmode(TRANSPARENT);
	gcontinue();
}

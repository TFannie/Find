#pragma once
void manu(play *head,time_t *start);
void concel();
int choice(play *,time_t *);
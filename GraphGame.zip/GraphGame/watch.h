#pragma once
void watch(play *head);
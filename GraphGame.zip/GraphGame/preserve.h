#pragma once
void preserve(play *head);
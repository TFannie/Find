#pragma once
play *init();
play *origin();
void gcontinue();
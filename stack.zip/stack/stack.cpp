#include"stack.h"
#include"enum.h"

Status AStackConstruct(AStack * stk)
{
	stk->capacity = 10;
	stk->data = (int *)malloc(sizeof(int)*stk->capacity);
	if (stk->data == nullptr)return ERROR;
	stk->size=-1;
    return OK;
}

Status AStackPush(AStack * stk, int val)
{

	int jud = 0;
	if (stk==nullptr)
		return ERROR;
	if (stk->size + 1 >= stk->capacity)
	{
		jud=enlarge(stk);
		if (jud == 0)return ERROR;
	}
	stk->size += 1;
	stk->data[stk->size] = val;
	return OK;
	
}

Status AStackTop(const AStack * stk, int * pVal)
{
	if (stk == nullptr||stk->size==-1)return ERROR;
	*pVal = stk->data[stk->size];
	return OK;
}

Status AStackPop(AStack * stk, int * pVal) //pVal��ȡջ��ֵ��Ҳ��Ϊ�գ������Ա��У����ջ������free����������
{
	if (stk == nullptr || stk->size == -1)return ERROR;
	*pVal = stk->data[stk->size];   
	stk->size--;
	return OK;

}

Status AStackSize(const AStack * stk, int * pSize)
{
	if (stk == nullptr)return ERROR;
	*pSize = stk->size;
	return OK;
}

Status AStackDestroy(AStack * stk)
{
	if (stk == nullptr)return ERROR;   //��ֹ����free
	if(stk->size>-1)free(stk->data);
	free(stk);
	return OK;
}

Status enlarge(AStack * stk)  //�ռ���������
{
	int *pdata,jud=0;
	pdata = (int *)malloc(stk->capacity*2*sizeof(int));
	if (pdata == nullptr)return ERROR;
	while (jud < stk->capacity)
	{
		pdata[jud] = stk->data[jud];
		jud++;
	}
	free(stk->data);
	stk->data = pdata;
	stk->capacity *= 2;
	return OK;
}


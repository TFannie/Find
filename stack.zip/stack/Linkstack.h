#pragma once
// C����ʵ����ջ
#include<cstdio>
#include<cstdlib>
#include"enum.h"
typedef struct Node {
	int val;
	struct Node* next;
} Node, *PNode, *List;


typedef struct {
	List data;
	int size;
} LStack;



Status LStackConstruct(LStack* stk);
Status LStackPush(LStack* stk, int val);
Status LStackTop(const LStack* stk, int* pVal);
Status LStackPop(LStack* stk, int* pVal);	// pVal��ȡջ��ֵ��Ҳ��Ϊ�� 
Status LStackSize(const LStack* stk, int* pSize);
Status LStackDestroy(LStack* stk);
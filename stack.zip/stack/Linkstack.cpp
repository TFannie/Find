#include"Linkstack.h"

Status LStackConstruct(LStack * stk)
{
	if (stk == nullptr)return ERROR;
	stk->size = 0;       //size��ʾ�ж��������ݣ���ʼ��0��
	stk->data = nullptr;
	return OK;
}

Status LStackPush(LStack * stk, int val)
{
	Node *p;
	if (stk == nullptr)return ERROR;
	p = (List)malloc(sizeof(Node));
	if (p == nullptr)return ERROR;
	p->next = stk->data;
	stk->data = p;
	p->val = val;
	stk->size++;
	return OK;
}

Status LStackTop(const LStack * stk, int * pVal)
{
	if (stk == nullptr||stk->size<=0)return ERROR;
	*pVal = stk->data->val;
	return OK;
}

Status LStackPop(LStack * stk, int * pVal)
{
	PNode p;
	if (stk == nullptr||stk->data==nullptr)return ERROR;
	p = stk->data;
	*pVal = stk->data->val;
	stk->data = p->next;
	free(p);
	p = nullptr;
	stk->size--;
	return OK;
}

Status LStackSize(const LStack * stk, int * pSize)
{
	if (stk == nullptr)return ERROR;
	*pSize = stk->size;
	return OK;
}

Status LStackDestroy(LStack * stk)
{
	PNode p;
	if (stk == nullptr)return ERROR;
	while (stk->data != nullptr)
	{
		p = stk->data;
		stk->data = p->next;
		free(p); p = nullptr;  //��������free������nullptr��ϰ��
	}
	free(stk);
	return OK;
}

#pragma once
typedef enum Status
{
	ERROR = 0, OK = 1
}Status;